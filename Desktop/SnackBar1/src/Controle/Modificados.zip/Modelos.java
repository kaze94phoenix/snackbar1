/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controle;

import Modelos.Alimento;
import Modelos.Bebidas;
import Modelos.Usuario;
import java.sql.SQLException;
import java.util.Vector;
import javafx.collections.ObservableList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Gaara-X
 */
public class Modelos {
    
    public static DefaultTableModel modeloU() throws Exception {
        DefaultTableModel modelo = new DefaultTableModel();
         //ConectaBanco.lerUsuarios();
         modelo.setColumnCount(5);
         modelo.setColumnIdentifiers(new Object[] {"Nome","Nr BI","Data de nascimento","Genero","Contacto","Endereco","Nome de usuario","Senha","Categoria"});
         for(Usuario u:ConectaBanco.lerUsuarios())
             modelo.addRow(new Object[]{" "+u.getNome(),u.getBi(),u.getDataNasc(),u.getGenero(),u.getContacto(),u.getEndereco(),u.getUsername(),u.getPassword(),u.getCategoria()});
         
         return modelo;
    }
    
    public static DefaultTableModel modeloA() throws Exception {
        DefaultTableModel modelo = new DefaultTableModel();
         modelo.setColumnCount(2);
         modelo.setColumnIdentifiers(new Object[] {"Nome","Preco"});
         for(Alimento a:ConectaBanco.lerAlimentos())
             modelo.addRow(new Object[]{" "+a.getNome(),a.getPreco()});
         
         return modelo;
    }
    
   public static DefaultTableModel modeloB() throws Exception {
        DefaultTableModel modelo = new DefaultTableModel();
         modelo.setColumnCount(3);
         modelo.setColumnIdentifiers(new Object[] {"Nome","Preco","Alcoolica"});
         for(Bebidas b:ConectaBanco.lerBebida())
             modelo.addRow(new Object[]{" "+b.getNome(),b.getPreco(),b.isAlcoolica()});
         
         return modelo;
    }
       public static DefaultComboBoxModel listaComidas() throws SQLException{
         //  DefaultComboBoxModel modelo = new DefaultComboBoxModel();
           Vector<String> v = new Vector();
           for(Alimento a:ConectaBanco.lerAlimentos())
               v.add(a.getNome());
               DefaultComboBoxModel modelo = new DefaultComboBoxModel(v);

        return modelo;
    }
       
              public static DefaultComboBoxModel bebidasAlcoolicas() throws  Exception{
         //  DefaultComboBoxModel modelo = new DefaultComboBoxModel();
           Vector<String> v = new Vector();
           for(Bebidas b:ConectaBanco.lerBebida())
               if(b.isAlcoolica())
               v.add(b.getNome());
               DefaultComboBoxModel modelo = new DefaultComboBoxModel(v);

        return modelo;
    }
                     public static DefaultComboBoxModel bebidasNaoAlcoolicas() throws Exception{
         //  DefaultComboBoxModel modelo = new DefaultComboBoxModel();
           Vector<String> v = new Vector();
           for(Bebidas b:ConectaBanco.lerBebida())
               if(!b.isAlcoolica())
               v.add(b.getNome());
               DefaultComboBoxModel modelo = new DefaultComboBoxModel(v);

        return modelo;
    }
    public static DefaultComboBoxModel listaUsuarios() throws Exception{
         //  DefaultComboBoxModel modelo = new DefaultComboBoxModel();
           Vector<String> v = new Vector();
           for(Usuario u:ConectaBanco.lerUsuarios())
               v.add(u.getNome());
               DefaultComboBoxModel modelo = new DefaultComboBoxModel(v);

        return modelo;
    }
       public static DefaultComboBoxModel listaBebidas() throws Exception{
         //  DefaultComboBoxModel modelo = new DefaultComboBoxModel();
           Vector<String> v = new Vector();
           for(Bebidas b:ConectaBanco.lerBebida())
               v.add(b.getNome());
               DefaultComboBoxModel modelo = new DefaultComboBoxModel(v);

        return modelo;
    }
              public static DefaultComboBoxModel modeloMesas() throws Exception{
         //  DefaultComboBoxModel modelo = new DefaultComboBoxModel();
           Vector<String> v = new Vector();
           //for(Bebidas b:ConectaBanco.lerBebida())
                  for (int i = 1; i < 5; i++) {
                   v.add("Mesa "+i);   
                  }
               
               DefaultComboBoxModel modelo = new DefaultComboBoxModel(v);

        return modelo;
    }


}