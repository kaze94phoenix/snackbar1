/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Interface;

import Controle.Botao;
import Controle.TrataVenda;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.ComboBox;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EtchedBorder;

/**
 *
 * @author Junior
 */
public class Adicao extends JPanel {
    public Adicao(){
       criacao();
    }
    public boolean getScrollableTracksViewportWidth(){
        return true;
    }
    public static JComboBox comidas,bebidas,bebidasN,mesas;
    JPanel painel,pain,pain1,pain2,pain3,pain4,pain5,spPainelBebidas,painelBebidas,painelAlcoolicas,painelNAlcoolicas,painelBotoes,painelDados,painelComidas,painelDadosComidas,painelMesas,painelEdicao;
    public static JButton adicionarBA,adicionarBNA,adicionarC,confirmar;
    EtchedBorder borda;
    ButtonGroup grupo;
    JRadioButton[] botoes;
    JTextArea lista;
    public static JTextArea texto;
    public static JTextField quantidadeBA,quantidadeBNA,quantidadeC;
    JScrollPane scroll;
    public void criacao(){
        EtchedBorder borda = new EtchedBorder(EtchedBorder.RAISED);
        painelEdicao= new JPanel(new GridLayout());
        painelMesas= new JPanel(new GridLayout(3,1));
        painelComidas = new JPanel(new GridLayout(2,1));
        painelDadosComidas= new JPanel();
        painelDados= new JPanel();
        painelDados.setLayout(new GridLayout(1,4));
        painelBotoes= new JPanel();
        painelBotoes.setLayout(new GridLayout(4,1));
        painelBebidas= new JPanel();
        painelBebidas.setLayout(new GridLayout(4,1,5,5));        
        painelNAlcoolicas= new JPanel();
        painelAlcoolicas= new JPanel();
        painelAlcoolicas.setLayout(new BorderLayout(10,3));
        painelNAlcoolicas.setLayout(new BorderLayout(10,3));
        spPainelBebidas = new JPanel();
        spPainelBebidas.setLayout(new BorderLayout(10,3));
        spPainelBebidas.setBorder(borda);
         quantidadeBA = new JTextField(2);
         quantidadeBNA = new JTextField(2);
         quantidadeBNA.setToolTipText("Quantidade");
         quantidadeBA.setToolTipText("Quantidade");
         quantidadeC = new JTextField(2);
         quantidadeC.setToolTipText("Quantidade");
        
        texto =new JTextArea();
        //texto.setEditable(false);
        //texto.setContentType("text/html");
        texto.setText("tdfff");
        scroll= new JScrollPane(texto);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        confirmar = new JButton("Confirmar");
        botoes = new JRadioButton[6];
        grupo = new ButtonGroup();
        borda = new EtchedBorder(EtchedBorder.RAISED);
        try {
            bebidasN = new JComboBox(Controle.Modelos.bebidasNaoAlcoolicas());
           mesas = new JComboBox(Controle.Modelos.modeloMesas());
        } catch (Exception ex) {
            Logger.getLogger(Adicao.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            comidas = new JComboBox(Controle.Modelos.listaComidas());
        } catch (SQLException ex) {
            Logger.getLogger(Adicao.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            bebidas= new JComboBox(Controle.Modelos.bebidasAlcoolicas());
        } catch (Exception ex) {
            Logger.getLogger(Adicao.class.getName()).log(Level.SEVERE, null, ex);
        }
        painel = new JPanel();
        pain= new JPanel();
        pain1 = new JPanel();
        pain2 = new JPanel();
        pain3 = new JPanel();
        pain4 = new JPanel();
        //painel.setLayout(new BorderLayout());
        painel.setLayout(new GridLayout(2,1));
        pain.setLayout(new GridLayout(2,1,5,5));
        pain1.setLayout(new GridLayout(1,2));
        pain1.setBorder(borda);
        pain2.setBorder(borda);
        pain3.setLayout(new BorderLayout());
        pain3.setBorder(borda);
        
        adicionarBA = new JButton("Adicionar");
        adicionarBNA = new JButton("Adicionar");
        adicionarC = new JButton("Adicionar");
        adicionarC.addActionListener(new TrataVenda());
        adicionarBA.addActionListener(new TrataVenda());
        adicionarBNA.addActionListener(new TrataVenda());
        confirmar.addActionListener(new TrataVenda());
        
        painelBotoes.add(new JLabel(""));
        painelBotoes.add(adicionarBA);
        painelBotoes.add(new JLabel(""));
        painelBotoes.add(adicionarBNA);
        
        painelNAlcoolicas.add(bebidasN,BorderLayout.CENTER);
        painelNAlcoolicas.add(quantidadeBNA,BorderLayout.EAST);
        painelAlcoolicas.add(bebidas,BorderLayout.CENTER);
        painelAlcoolicas.add(quantidadeBA,BorderLayout.EAST);

        painelBebidas.add(new JLabel("Bebidas Alcoolicas"));
        painelBebidas.add(painelAlcoolicas);
        painelBebidas.add(new JLabel("Bebidas nao Alcoolicas"));
        painelBebidas.add(painelNAlcoolicas);
        spPainelBebidas.add(painelBebidas,BorderLayout.CENTER);
        spPainelBebidas.add(painelBotoes,BorderLayout.EAST);
        
        painelDadosComidas.add(new JLabel("Comidas"));
        painelDadosComidas.add(comidas);
        painelDadosComidas.add(quantidadeC);
        painelDadosComidas.add(adicionarC);
        painelComidas.add(painelDadosComidas);
        //pain2.add(new JLabel("              "));
        painelDados.add(painelDadosComidas);
        painelDados.add(spPainelBebidas);
        
        painelMesas.add(new JLabel(""));
        painelMesas.add(mesas);
        painelMesas.add(new JLabel(""));
        pain1.add(painelMesas);
        pain1.add(painelEdicao);
        //lista.setAutoscrolls(true);
        pain3.add(new JLabel("Lista de itens para a mesa"),BorderLayout.PAGE_START);
        pain3.add(scroll,BorderLayout.CENTER);
        pain3.add(confirmar,BorderLayout.EAST);
        //pain3.add(confirmar,BorderLayout.SOUTH);
        pain.add(painelDados);
        pain.add(pain1);
        this.setLayout(new BorderLayout());
        this.add(pain,BorderLayout.NORTH);
        this.add(pain3,BorderLayout.CENTER);
    }
    public static void main(String[] args) {
        JFrame f = new JFrame();
        f.add(new Adicao());
        f.setSize(800, 600);
        //f.pack();
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
